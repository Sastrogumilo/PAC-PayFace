import 'package:PayFace/register.dart';
import 'package:flutter/material.dart';
//import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/services.dart';
import 'login.dart';
import 'home_page.dart';
import 'dashboard.dart';
import 'profil.dart';
import 'register.dart';

void main() {
  SystemChrome.setEnabledSystemUIOverlays([]);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  final routes = <String, WidgetBuilder>{
    LoginPage.tag: (context) => LoginPage(),
    HomePage.tag: (context) => HomePage(),
    DashBoardPage.tag: (context) => DashBoardPage(),
    ProfilPage.tag: (context) => ProfilPage(),
    RegisterPage.tag: (context) => RegisterPage(),
  };
  
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PayFace',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        fontFamily: 'Nunito',
      ),
      home: LoginPage(),
      routes: routes,
    );
  }
}